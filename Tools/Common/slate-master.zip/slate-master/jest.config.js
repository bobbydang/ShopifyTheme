module.exports = {
  testPathIgnorePatterns: [
    '/node_modules/',
    '/lib/',
    'packages/slate-tools/src/commands/test.js',
    '__tests__/fixtures/',
    '__tests__/helpers',
  ],
};
