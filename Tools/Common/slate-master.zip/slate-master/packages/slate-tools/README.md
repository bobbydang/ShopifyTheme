[![npm version](https://badge.fury.io/js/%40shopify%2Fslate-tools.svg)](https://badge.fury.io/js/%40shopify%2Fslate-tools)

# @shopify/slate-tools

Slate Tools provides a sophisticated development experience enabling users to build top-notch Shopify themes.

For more information, visit [the Wiki](https://github.com/Shopify/slate/wiki/Slate%20Tools).
