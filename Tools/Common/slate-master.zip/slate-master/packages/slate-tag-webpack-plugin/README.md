# @shopify/slate-tag-webpack-plugin

A webpack plugin that tags a Slate theme settings_schema.json so it's easy to identify on Shopify servers.
