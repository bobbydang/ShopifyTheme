module.exports = {
  id: 'testSchema',
  items: [
    {
      id: 'test-item',
      default: 'default-value',
      type: 'string',
    },
  ],
};
