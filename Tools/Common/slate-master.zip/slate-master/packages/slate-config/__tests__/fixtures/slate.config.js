module.exports = {
  testSchema: {
    'test-item': 'override-value',
  },
  otherSchema: {
    'other-item': 'other-value',
  },
};
