module.exports = {
  id: 'otherSchema',
  items: [
    {
      id: 'other-item',
      default: 'other-default-value',
      type: 'string',
    },
  ],
};
