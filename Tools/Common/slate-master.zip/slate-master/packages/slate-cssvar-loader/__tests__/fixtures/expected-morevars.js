exports = module.exports = require("../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.id, ".heading {\n  color: {{ settings.headings_color }};\n  background-color: '#FF00FF';\n}\n\n.title {\n  color: {{ settings.headings_color }};\n}\n\nbody {\n  background-color: {{ settings.body_color }};\n  color: {{ settings.extra_variable }};\n}", ""]);

// exports
