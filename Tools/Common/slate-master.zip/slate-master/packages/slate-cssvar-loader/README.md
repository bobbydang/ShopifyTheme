[![npm version](https://badge.fury.io/js/%40shopify%2Fslate-cssvar-loader.svg)](https://badge.fury.io/js/%40shopify%2Fslate-cssvar-loader)

# @shopify/slate-cssvar-loader

Finds CSS custom properties (variables) in your stylesheets and replaces them with their corresponding Liquid variable found in the provided `cssVariablesPath` option.

For more information, visit [the Wiki](https://github.com/Shopify/slate/wiki/Slate-CSSVar-Loader).
