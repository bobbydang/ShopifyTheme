[![npm version](https://badge.fury.io/js/%40shopify%2Fslate-analytics.svg)](https://badge.fury.io/js/%40shopify%2Fslate-analytics)

# @shopify/slate-analytics

Slate Analytics enables Shopify to track Slate user events, performance data, and errors to Shopify's analytics platform.

For more information, visit [the Wiki](https://github.com/Shopify/slate/wiki/Slate-Analytics).
