# @shopify/slate-rc

Slate's global configuration manager. Generates, reads, and applies values to a global .slaterc file
